const defaultUrl = 'http://localhost:3333';

export default {
  profile_image: `${defaultUrl}/files`,
};
