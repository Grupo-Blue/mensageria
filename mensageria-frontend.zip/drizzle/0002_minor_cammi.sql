ALTER TABLE `settings` ADD `resume_prompt` text;--> statement-breakpoint
ALTER TABLE `settings` ADD `resume_connection_id` int;