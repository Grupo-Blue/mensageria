export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

export const APP_TITLE = "Mensageria";

export const APP_LOGO = "/logo.png";

// Generate login URL for Google OAuth
export const getLoginUrl = () => {
  // Usar Google OAuth direto
  return `${window.location.origin}/api/auth/google`;
};

// URL de login legado (Manus OAuth) - manter para compatibilidade
export const getManusLoginUrl = () => {
  const oauthPortalUrl = import.meta.env.VITE_OAUTH_PORTAL_URL;
  const appId = import.meta.env.VITE_APP_ID;
  
  // Se as variáveis não estiverem configuradas, retorna URL do Google OAuth
  if (!oauthPortalUrl || !appId) {
    return getLoginUrl();
  }
  
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${oauthPortalUrl}/app-auth`);
  url.searchParams.set("appId", appId);
  url.searchParams.set("redirectUri", redirectUri);
  url.searchParams.set("state", state);
  url.searchParams.set("type", "signIn");

  return url.toString();
};